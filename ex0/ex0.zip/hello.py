##############################################
# FILE: hello.py
# WRITER: Or Mizrahi, Xelanos, 308484625
# DESCRIPTION: A simple program that prints "Hello World!" to
# the standard outpt(screen).
##############################################
print("Hello World!")
