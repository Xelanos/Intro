def convert_spoon_to_cup(spoons):
    """ A function that takes the number of spoons
    and convert them to cups (1 cup = 3 .5 spoons)
    """
    CUP_RATIO=3.5
    cups=spoons/CUP_RATIO #calculate the cups
    return cups

